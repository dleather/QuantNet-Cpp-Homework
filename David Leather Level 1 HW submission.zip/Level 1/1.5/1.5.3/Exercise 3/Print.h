#pragma once
#ifndef PRINT_H
#define PRINT_H
int print(double i);

#endif