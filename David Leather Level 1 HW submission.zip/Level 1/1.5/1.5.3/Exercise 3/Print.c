// Author: David Leather. Date: 1/6/2025.
// QuantNet C++ Course 1: Level 1, Section 1.5, Exercise 3
// Multiplies i by 2 and prints it.

#include <stdio.h>

// Doubles i and prints
int print(double i)
{
	printf("%.2f times two is equals to %.2f.\n", i, 2.0 * i);

	return 0;
}