// Author: David Leather. Date: 1/6/2025.
// QuantNet C++ Course 1: Level 1, Section 1.5, Exercise 3
// Calls print() function defined in Print.c

#include "Print.h"

int main()
{
	double i = 5.0; //Number to be doubled
	print(i);
	return 0;
}

