// Author: David Leather. Date: 1/3/2025.
// QuantNet C++ Course 1: Level 1, Section 1.3, Exercise 1

#include <stdio.h> // Import the "stdio.h" header file

int main() // Start of program
{
	printf("My first C-program\nis a fact!\nGood, isn't it?");

	return 0;
}